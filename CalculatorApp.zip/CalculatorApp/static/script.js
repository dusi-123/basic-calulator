let display = document.getElementById("display");

function appendNumber(number) {
    display.value += number;
}

function appendOperator(operator) {
    if (display.value === "") return;
    const lastChar = display.value[display.value.length - 1];
    if ("+-*/".includes(lastChar)) return; // Prevent multiple operators
    display.value += operator;
}

function clearDisplay() {
    display.value = "";
}

function backspace() {
    display.value = display.value.slice(0, -1);
}

async function calculate() {
    const expression = display.value;
    if (!expression) return;

    try {
        const response = await fetch("/calculate", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ expression }),
        });
        const data = await response.json();

        if (response.ok) {
            display.value = data.result;
        } else {
            display.value = "Error";
        }
    } catch (error) {
        display.value = "Error";
        console.error("Calculation error:", error);
    }
}

// Add functionality for %
function appendPercentage() {
    if (display.value !== "") {
        display.value = (parseFloat(display.value) / 100).toString();
    }
}

// Add functionality for 00
function appendDoubleZero() {
    if (display.value !== "") {
        display.value += "00";
    }
}
